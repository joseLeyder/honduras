<?php
    return [
    'optionsDefault' => [
        'logineMaxTrys' => 6,
        'logeoAutomaticoEnSucursal' => true,
        'idSucursalLogeoAutomatico' => 1,
        'minutosExpirationToken' => 480,
        ]
    ];
