<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class PaseListaCongresistaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
