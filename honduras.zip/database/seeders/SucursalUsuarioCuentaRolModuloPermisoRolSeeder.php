<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class SucursalUsuarioCuentaRolModuloPermisoRolSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
