<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class TipoMultimediaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
