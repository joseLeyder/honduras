<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class SucursalUsuarioCuentaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
