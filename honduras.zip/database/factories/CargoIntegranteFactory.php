<?php

namespace Database\Factories;

use App\Models\CargoIntegrante;
use Illuminate\Database\Eloquent\Factories\Factory;

class CargoIntegranteFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = CargoIntegrante::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
