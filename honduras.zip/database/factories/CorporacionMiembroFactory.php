<?php

namespace Database\Factories;

use App\Models\CorporacionMiembro;
use Illuminate\Database\Eloquent\Factories\Factory;

class CorporacionMiembroFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = CorporacionMiembro::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
