<?php

namespace Database\Factories;

use App\Models\TipoRespuestaVotacion;
use Illuminate\Database\Eloquent\Factories\Factory;

class TipoRespuestaVotacionFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = TipoRespuestaVotacion::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
