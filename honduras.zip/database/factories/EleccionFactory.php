<?php

namespace Database\Factories;

use App\Models\Eleccion;
use Illuminate\Database\Eloquent\Factories\Factory;

class EleccionFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Eleccion::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
