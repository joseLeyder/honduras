<?php

namespace Database\Factories;

use App\Models\SecretarioImagen;
use Illuminate\Database\Eloquent\Factories\Factory;

class SecretarioImagenFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = SecretarioImagen::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
