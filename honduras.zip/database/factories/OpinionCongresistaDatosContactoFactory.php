<?php

namespace Database\Factories;

use App\Models\OpinionCongresistaDatosContacto;
use Illuminate\Database\Eloquent\Factories\Factory;

class OpinionCongresistaDatosContactoFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = OpinionCongresistaDatosContacto::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
