<?php

namespace Database\Factories;

use App\Models\TipoCitante;
use Illuminate\Database\Eloquent\Factories\Factory;

class TipoCitanteFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = TipoCitante::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
