<?php

namespace Database\Factories;

use App\Models\CongresoVisibleEquipoIntegrante;
use Illuminate\Database\Eloquent\Factories\Factory;

class CongresoVisibleEquipoIntegranteFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = CongresoVisibleEquipoIntegrante::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
