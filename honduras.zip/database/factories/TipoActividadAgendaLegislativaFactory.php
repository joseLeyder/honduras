<?php

namespace Database\Factories;

use App\Models\TipoActividadAgendaLegislativa;
use Illuminate\Database\Eloquent\Factories\Factory;

class TipoActividadAgendaLegislativaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = TipoActividadAgendaLegislativa::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
