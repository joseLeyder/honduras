<?php

namespace Database\Factories;

use App\Models\PaseLista;
use Illuminate\Database\Eloquent\Factories\Factory;

class PaseListaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = PaseLista::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
