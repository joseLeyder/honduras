<?php

namespace Database\Factories;

use App\Models\PersonaDatoContacto;
use Illuminate\Database\Eloquent\Factories\Factory;

class PersonaDatoContactoFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = PersonaDatoContacto::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
