<?php

namespace Database\Factories;

use App\Models\TemaBlogNd;
use Illuminate\Database\Eloquent\Factories\Factory;

class TemaBlogNdFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = TemaBlogNd::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
