<?php

namespace Database\Factories;

use App\Models\BalanceCuatrienioImagen;
use Illuminate\Database\Eloquent\Factories\Factory;

class BalanceCuatrienioImagenFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = BalanceCuatrienioImagen::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
