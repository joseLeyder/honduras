<?php

namespace Database\Factories;

use App\Models\ProyectoLeyEstado;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProyectoLeyEstadoFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = ProyectoLeyEstado::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
