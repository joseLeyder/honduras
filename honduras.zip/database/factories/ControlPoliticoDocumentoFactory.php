<?php

namespace Database\Factories;

use App\Models\ControlPoliticoDocumento;
use Illuminate\Database\Eloquent\Factories\Factory;

class ControlPoliticoDocumentoFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = ControlPoliticoDocumento::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
