<?php

namespace Database\Factories;

use App\Models\Alcance;
use Illuminate\Database\Eloquent\Factories\Factory;

class AlcanceFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Alcance::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
