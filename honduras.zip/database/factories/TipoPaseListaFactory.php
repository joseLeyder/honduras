<?php

namespace Database\Factories;

use App\Models\TipoPaseLista;
use Illuminate\Database\Eloquent\Factories\Factory;

class TipoPaseListaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = TipoPaseLista::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
