<?php

namespace Database\Factories;

use App\Models\VotacionPlenaria;
use Illuminate\Database\Eloquent\Factories\Factory;

class VotacionPlenariaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = VotacionPlenaria::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
