<?php

namespace Database\Factories;

use App\Models\GrupoEdad;
use Illuminate\Database\Eloquent\Factories\Factory;

class GrupoEdadFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = GrupoEdad::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
