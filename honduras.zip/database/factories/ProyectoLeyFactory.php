<?php

namespace Database\Factories;

use App\Models\ProyectoLey;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProyectoLeyFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = ProyectoLey::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
