<?php

namespace Database\Factories;

use App\Models\Profesion;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProfesionFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Profesion::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
