<?php

namespace Database\Factories;

use App\Models\VotacionComision;
use Illuminate\Database\Eloquent\Factories\Factory;

class VotacionComisionFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = VotacionComision::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
