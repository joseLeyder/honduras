<?php

namespace Database\Factories;

use App\Models\CongresistaReemplazo;
use Illuminate\Database\Eloquent\Factories\Factory;

class CongresistaReemplazoFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = CongresistaReemplazo::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
