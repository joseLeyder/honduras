<?php

namespace Database\Factories;

use App\Models\Corporacion;
use Illuminate\Database\Eloquent\Factories\Factory;

class CorporacionFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Corporacion::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
