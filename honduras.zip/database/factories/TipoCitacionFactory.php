<?php

namespace Database\Factories;

use App\Models\TipoCitacion;
use Illuminate\Database\Eloquent\Factories\Factory;

class TipoCitacionFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = TipoCitacion::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
