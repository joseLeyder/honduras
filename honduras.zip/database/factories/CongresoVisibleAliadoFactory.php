<?php

namespace Database\Factories;

use App\Models\CongresoVisibleAliado;
use Illuminate\Database\Eloquent\Factories\Factory;

class CongresoVisibleAliadoFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = CongresoVisibleAliado::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
