<?php

namespace Database\Factories;

use App\Models\CongresoVisibleAliadoImagen;
use Illuminate\Database\Eloquent\Factories\Factory;

class CongresoVisibleAliadoImagenFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = CongresoVisibleAliadoImagen::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
