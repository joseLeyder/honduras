<?php

namespace Database\Factories;

use App\Models\TipoSucursal;
use Illuminate\Database\Eloquent\Factories\Factory;

class TipoSucursalFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = TipoSucursal::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
