<?php

namespace Database\Factories;

use App\Models\ProyectoLeyAutor;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProyectoLeyAutorFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = ProyectoLeyAutor::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
